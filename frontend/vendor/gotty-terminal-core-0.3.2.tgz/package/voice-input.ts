export interface VoiceTerminal {
 elem: HTMLElement;
 showMessage(text:string,timeout:number):void;
 removeMessage():void;
 disableStdin():void;
 enableStdin():void;
 sendInput(data:Uint8Array):void;
}

declare var gotty_ws_query_args: string;

type StartMode = 'button' | 'hotkey';

export interface VoiceInputOptions {
    term: VoiceTerminal;
    authToken: string;
    enabled: boolean;
    permitWrite: boolean;
    holdMs: number;
    hotkeyCode: string;
    webSocketFactory?:()=>WebSocket;
    initialize?: (ws:WebSocket)=>Promise<void>;
}

export class VoiceInput {
    private term: VoiceTerminal;
    private options: VoiceInputOptions;
    private authToken: string;
    private enabled: boolean;
    private permitWrite: boolean;
    private holdMs: number;
    private hotkeyCode: string;

    private button: HTMLButtonElement;
    private buttonIcon: HTMLElement;

    private positionTimer: number | null = null;

    private holdTimer: number | null = null;
    private holdArmed: boolean = false;

    private recording: boolean = false;
    private captureEnabled: boolean = false;
    private startMode: StartMode = 'button';

    private ws: WebSocket | null = null;
    private sessionSeq: number = 0;
    private activeSession: number = 0;

    private audioCtx: AudioContext | null = null;
    private recorder: ScriptProcessorNode | null = null;
    private mediaStream: MediaStream | null = null;
    private recordSampleRate: number = 48000;

    private expectedSampleRate: number = 16000;

    private segments: Map<number, string> = new Map();
    private stopFinalizeTimer: number | null = null;

    private encoder: TextEncoder = new TextEncoder();

    private termFocused: boolean = false;

    private postStopMessage: { text: string; timeout: number } | null = null;

    constructor(opts: VoiceInputOptions) {
        this.options = opts;
        this.term = opts.term;
        this.authToken = opts.authToken;
        this.enabled = opts.enabled;
        this.permitWrite = opts.permitWrite;
        this.holdMs = opts.holdMs;
        this.hotkeyCode = opts.hotkeyCode;

        this.button = document.createElement('button');
        this.button.type = 'button';
        this.button.className = 'gotty-voice-btn';
        this.button.title = '语音输入（点击开始/停止；按住右 Shift 开始，松开停止）';
        this.button.setAttribute('aria-label', 'Voice input');
        this.buttonIcon = document.createElement('span');
        this.buttonIcon.className = 'gotty-voice-btn__icon';
        this.buttonIcon.innerHTML = `
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false">
              <path fill="currentColor" d="M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2Z"/>
            </svg>
        `;
        this.button.appendChild(this.buttonIcon);

        this.button.addEventListener('click', () => {
            if (!this.enabled) return;
            if (this.recording) {
                this.stop();
            } else {
                this.start('button');
            }
        });

        this.term.elem.appendChild(this.button);

        this.term.elem.addEventListener('focusin', () => { this.termFocused = true; });
        this.term.elem.addEventListener('focusout', () => { this.termFocused = false; });
        const activeElem = document.activeElement;
        this.termFocused = !!activeElem && this.term.elem.contains(activeElem);

        document.addEventListener('keydown', this.onKeyDownCapture, true);
        document.addEventListener('keyup', this.onKeyUpCapture, true);
        window.addEventListener('blur', this.onWindowBlur);
        document.addEventListener('visibilitychange', this.onVisibilityChange);

        this.positionTimer = window.setInterval(() => {
            this.updateUI();
        }, 100);

        this.updateUI();
    }

    close() {
        this.cancelHold();
        if (this.recording) {
            this.finalizeStop(true);
        }

        if (this.positionTimer !== null) {
            window.clearInterval(this.positionTimer);
            this.positionTimer = null;
        }

        document.removeEventListener('keydown', this.onKeyDownCapture, true);
        document.removeEventListener('keyup', this.onKeyUpCapture, true);
        window.removeEventListener('blur', this.onWindowBlur);
        document.removeEventListener('visibilitychange', this.onVisibilityChange);

        try {
            this.term.elem.removeChild(this.button);
        } catch (_) {
        }
    }

    private updateUI() {
        if (!this.enabled) {
            this.button.style.display = 'none';
            return;
        }

        this.button.style.display = '';
        this.button.disabled = false;
        this.button.classList.toggle('gotty-voice-btn--disabled', !this.permitWrite || !this.canAccessMicFromHere());
        if (!this.permitWrite) {
            this.button.title = '语音输入不可用：gotty 需要 --permit-write';
        } else if (!this.canAccessMicFromHere()) {
            this.button.title = '语音输入不可用：需要 HTTPS 安全上下文才能访问麦克风（可尝试用 http://localhost 或启用 gotty --tls）';
        } else {
            this.button.title = '语音输入（点击开始/停止；按住右 Shift 开始，松开停止）';
        }

        if (this.recording) {
            this.button.classList.add('gotty-voice-btn--active');
        } else {
            this.button.classList.remove('gotty-voice-btn--active');
        }

        this.button.classList.add('gotty-voice-btn--fallback');
        this.button.style.left = '';
        this.button.style.top = '';
    }

    private onKeyDownCapture = (ev: KeyboardEvent) => {
        if (!this.enabled) return;
        if (!this.permitWrite) return;
        if (!this.termFocused) return;

        if (this.recording) {
            return;
        }

        if (this.holdArmed && ev.code !== this.hotkeyCode) {
            this.cancelHold();
            return;
        }

        if (ev.code !== this.hotkeyCode) return;
        if (ev.repeat) return;
        if (ev.altKey || ev.ctrlKey || ev.metaKey) return;

        this.armHold();
    };

    private onKeyUpCapture = (ev: KeyboardEvent) => {
        if (ev.code !== this.hotkeyCode) return;

        if (this.holdArmed) {
            this.cancelHold();
            return;
        }

        if (this.recording && this.startMode === 'hotkey') {
            this.stop();
        }
    };

    private onWindowBlur = () => {
        this.cancelHold();
        if (this.recording && this.startMode === 'hotkey') {
            this.stop();
        }
    };

    private onVisibilityChange = () => {
        if (document.visibilityState !== 'visible') {
            this.cancelHold();
            if (this.recording && this.startMode === 'hotkey') {
                this.stop();
            }
        }
    };

    private armHold() {
        if (this.holdArmed) return;
        this.holdArmed = true;
        this.holdTimer = window.setTimeout(() => {
            this.holdTimer = null;
            this.holdArmed = false;
            this.start('hotkey');
        }, this.holdMs);
    }

    private cancelHold() {
        this.holdArmed = false;
        if (this.holdTimer !== null) {
            window.clearTimeout(this.holdTimer);
            this.holdTimer = null;
        }
    }

    private canAccessMicFromHere(): boolean {
        return window.isSecureContext && typeof navigator.mediaDevices?.getUserMedia === 'function';
    }

    private isCurrentSession(session: number, ws?: WebSocket): boolean {
        if (session !== this.activeSession) return false;
        if (!this.recording) return false;
        if (ws && this.ws !== ws) return false;
        return true;
    }

    private waitForWsOpen(ws: WebSocket, timeoutMs: number, setDidOpen: () => void): Promise<void> {
        return new Promise<void>((resolve, reject) => {
            const timeout = window.setTimeout(() => {
                cleanup();
                reject(new Error("ASR websocket connect timeout"));
            }, timeoutMs);

            const onOpen = () => {
                setDidOpen();
                cleanup();
                resolve();
            };
            const onError = () => {
                cleanup();
                reject(new Error("ASR websocket error during connect"));
            };
            const onClose = (ev: CloseEvent) => {
                cleanup();
                const reason = ev.reason ? ` reason=${ev.reason}` : "";
                reject(new Error(`ASR websocket closed during connect (code=${ev.code}${reason})`));
            };

            const cleanup = () => {
                window.clearTimeout(timeout);
                ws.removeEventListener('open', onOpen);
                ws.removeEventListener('error', onError);
                ws.removeEventListener('close', onClose);
            };

            ws.addEventListener('open', onOpen);
            ws.addEventListener('error', onError);
            ws.addEventListener('close', onClose);
        });
    }

    private formatStartError(e: unknown): string {
        const err = e as { name?: unknown; message?: unknown };
        const name = typeof err?.name === 'string' ? err.name : '';
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
            return "无法开始语音输入：麦克风权限被拒绝";
        }
        if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
            return "无法开始语音输入：未检测到麦克风设备";
        }
        if (name === 'NotReadableError' || name === 'TrackStartError') {
            return "无法开始语音输入：麦克风被占用或不可用";
        }
        return "无法开始语音输入：连接 ASR 服务失败";
    }

    private buildAsrWsUrl(): string {
        const httpsEnabled = window.location.protocol === "https:";
        const proto = httpsEnabled ? 'wss://' : 'ws://';
        const queryArgs = (typeof gotty_ws_query_args === 'string' && gotty_ws_query_args !== "") ? "?" + gotty_ws_query_args : "";
        const basePath = window.location.pathname.endsWith('/') ? window.location.pathname : window.location.pathname + '/';
        return proto + window.location.host + basePath + 'asr/ws' + queryArgs;
    }

    private async start(mode: StartMode) {
        if (!this.enabled) return;
        if (!this.permitWrite) {
            this.term.showMessage("语音输入不可用：未启用写入权限（gotty 需要 --permit-write）", 2500);
            return;
        }
        if (this.recording) return;
        if (!this.canAccessMicFromHere()) {
            const origin = window.location.origin;
            this.term.showMessage(`语音输入需要 HTTPS 安全上下文才能访问麦克风（当前：${origin}；可尝试 http://localhost 或启用 gotty --tls）`, 3500);
            return;
        }

        const session = ++this.sessionSeq;
        this.activeSession = session;
        this.startMode = mode;
        this.recording = true;
        this.captureEnabled = true;
        this.segments.clear();

        this.term.disableStdin();
        this.term.showMessage("录音中，停止后插入", 0);

        try {
            const wsUrl = this.buildAsrWsUrl();
            const ws = this.options.webSocketFactory?.() ?? new WebSocket(wsUrl);
            ws.binaryType = 'arraybuffer';
            this.ws = ws;

            let didOpen = false;
            const setDidOpen = () => { didOpen = true; };

            ws.onmessage = (event: MessageEvent) => {
                if (this.ws !== ws) return;
                try {
                    const message = JSON.parse(event.data);
                    const segment = Number(message.segment);
                    const text = String(message.text ?? "");
                    if (Number.isFinite(segment)) {
                        this.segments.set(segment, text);
                    }

                    if (this.stopFinalizeTimer !== null) {
                        window.clearTimeout(this.stopFinalizeTimer);
                        this.stopFinalizeTimer = window.setTimeout(() => this.finalizeStop(), 250);
                    }
                } catch (_) {
                }
            };

            ws.onclose = (ev: CloseEvent) => {
                if (this.ws !== ws) return;
                if (this.stopFinalizeTimer !== null) {
                    window.clearTimeout(this.stopFinalizeTimer);
                }
                if (this.captureEnabled && didOpen) {
                    const reason = ev.reason ? `（${ev.reason}）` : "";
                    this.postStopMessage = { text: `语音输入连接已断开${reason}`, timeout: 2000 };
                }
                this.finalizeStop();
            };

            ws.onerror = () => {
                if (this.ws !== ws) return;
                if (!didOpen) return; // connect phase is handled by waitForWsOpen()
                this.postStopMessage = { text: "语音输入连接失败", timeout: 2000 };
                this.finalizeStop(true);
            };

            await this.waitForWsOpen(ws, 5000, setDidOpen);
            if (!this.isCurrentSession(session, ws)) {
                try { ws.close(); } catch (_) { }
                return;
            }

            if(this.options.initialize) await this.options.initialize(ws);
            else ws.send(JSON.stringify({ AuthToken: this.authToken, Arguments: "" }));

            await this.startAudioCapture();
            if (!this.isCurrentSession(session, ws)) {
                this.cleanupAudio();
                try { ws.close(); } catch (_) { }
                return;
            }
        } catch (e) {
            if (!this.isCurrentSession(session)) {
                return;
            }
            console.warn("voice input start failed:", e);
            this.postStopMessage = { text: this.formatStartError(e), timeout: 2500 };
            this.finalizeStop(true);
        }
    }

    private async startAudioCapture() {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        this.audioCtx = new AudioContext();
        this.recordSampleRate = this.audioCtx.sampleRate;

        const source = this.audioCtx.createMediaStreamSource(this.mediaStream);
        const bufferSize = 2048;
        this.recorder = this.audioCtx.createScriptProcessor(bufferSize, 1, 1);
        const gain = this.audioCtx.createGain();
        gain.gain.value = 0;

        this.recorder.onaudioprocess = (e) => {
            if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
            if (!this.captureEnabled) return;

			const input = new Float32Array(e.inputBuffer.getChannelData(0));
			const samples = this.downsampleBuffer(input, this.expectedSampleRate);
			const payload = new ArrayBuffer(samples.byteLength);
			new Float32Array(payload).set(samples);
			this.ws.send(payload);
		};

        source.connect(this.recorder);
        this.recorder.connect(gain);
        gain.connect(this.audioCtx.destination);
    }

    private stop() {
        if (!this.recording) return;
        this.cancelHold();

        if (!this.ws || this.ws.readyState === WebSocket.CONNECTING) {
            this.captureEnabled = false;
            this.cleanupAudio();
            this.cleanupWs();
            this.finalizeStop(true);
            return;
        }

        this.captureEnabled = false;
        this.cleanupAudio();

        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            try {
                this.ws.send("Done");
            } catch (_) {
            }
        }

        if (this.stopFinalizeTimer !== null) {
            window.clearTimeout(this.stopFinalizeTimer);
        }
        this.stopFinalizeTimer = window.setTimeout(() => this.finalizeStop(), 700);
    }

    private finalizeStop(skipInsert: boolean = false) {
        if (!this.recording) return;

        this.recording = false;
        this.activeSession = 0;
        this.captureEnabled = false;
        const postStopMessage = this.postStopMessage;
        this.postStopMessage = null;
        if (this.stopFinalizeTimer !== null) {
            window.clearTimeout(this.stopFinalizeTimer);
            this.stopFinalizeTimer = null;
        }

        const text = Array.from(this.segments.entries())
            .sort((a, b) => a[0] - b[0])
            .map(([, t]) => (t ?? "").trim())
            .filter((t) => t.length > 0)
            .join("，");

        if (!skipInsert && text.length > 0) {
            this.term.sendInput(this.encoder.encode(text));
        }

        this.term.enableStdin();
        this.term.removeMessage();
        this.cleanupAudio();
        this.cleanupWs();
        this.updateUI();

        if (postStopMessage) {
            this.term.showMessage(postStopMessage.text, postStopMessage.timeout);
        }
    }

    private cleanupWs() {
        if (this.ws) {
            try {
                this.ws.onmessage = null;
                this.ws.onclose = null;
                this.ws.onerror = null;
                if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
                    this.ws.close();
                }
            } catch (_) {
            }
        }
        this.ws = null;
    }

    private cleanupAudio() {
        try {
            if (this.recorder) {
                this.recorder.disconnect();
                this.recorder.onaudioprocess = null;
            }
        } catch (_) {
        }
        this.recorder = null;

        try {
            if (this.audioCtx && this.audioCtx.state !== 'closed') {
                this.audioCtx.close();
            }
        } catch (_) {
        }
        this.audioCtx = null;

        try {
            if (this.mediaStream) {
                this.mediaStream.getTracks().forEach(t => t.stop());
            }
        } catch (_) {
        }
        this.mediaStream = null;
    }

    private downsampleBuffer(buffer: Float32Array, exportSampleRate: number): Float32Array {
        if (exportSampleRate === this.recordSampleRate) {
            return buffer;
        }
        const sampleRateRatio = this.recordSampleRate / exportSampleRate;
        const newLength = Math.round(buffer.length / sampleRateRatio);
        const result = new Float32Array(newLength);
        let offsetResult = 0;
        let offsetBuffer = 0;
        while (offsetResult < result.length) {
            const nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
            let accum = 0;
            let count = 0;
            for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
                accum += buffer[i];
                count++;
            }
            result[offsetResult] = count > 0 ? (accum / count) : 0;
            offsetResult++;
            offsetBuffer = nextOffsetBuffer;
        }
        return result;
    }
}
